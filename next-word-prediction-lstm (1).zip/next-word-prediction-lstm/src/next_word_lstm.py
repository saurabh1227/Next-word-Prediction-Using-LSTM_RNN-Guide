"""
Next Word Prediction with SimpleRNN / LSTM (Keras)

Examples
--------
Train (if needed) and generate 15 words from a starting text:
    python src/next_word_lstm.py --seed-text "pizza is" --words 15

Use a SimpleRNN instead of LSTM, sample with temperature, more epochs:
    python src/next_word_lstm.py --model rnn --epochs 300 --seed-text "the crust" --words 10 --temperature 0.7

Interactive mode (asks for the starting text and number of words):
    python src/next_word_lstm.py --interactive
"""
import argparse
import json
import os
import re

os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "3")

import numpy as np
import tensorflow as tf
from tensorflow.keras.layers import LSTM, Dense, Embedding, Input, SimpleRNN
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.preprocessing.text import Tokenizer, tokenizer_from_json


def file_to_sentence_list(file_path):
    with open(file_path, "r", encoding="utf-8") as f:
        text = f.read()
    return [s.strip() for s in re.split(r"(?<=[.!?])\s+", text) if s.strip()]


def prepare_data(sentences):
    tokenizer = Tokenizer()
    tokenizer.fit_on_texts(sentences)
    total_words = len(tokenizer.word_index) + 1

    sequences = []
    for line in sentences:
        tokens = tokenizer.texts_to_sequences([line])[0]
        for i in range(1, len(tokens)):
            sequences.append(tokens[: i + 1])

    max_len = max(len(s) for s in sequences)
    sequences = np.array(pad_sequences(sequences, maxlen=max_len, padding="pre"))
    X, y = sequences[:, :-1], sequences[:, -1]
    y = tf.keras.utils.to_categorical(y, num_classes=total_words)
    return tokenizer, total_words, max_len, X, y


def build_model(cell, total_words, max_len, embed_dim=10, units=128):
    rnn = LSTM(units) if cell == "lstm" else SimpleRNN(units)
    model = Sequential([
        Input(shape=(max_len - 1,)),
        Embedding(total_words, embed_dim),
        rnn,
        Dense(total_words, activation="softmax"),
    ])
    model.compile(loss="categorical_crossentropy", optimizer="adam", metrics=["accuracy"])
    return model


def generate_text(model, tokenizer, max_len, seed_text, next_words, temperature=0.0):
    for _ in range(next_words):
        tokens = tokenizer.texts_to_sequences([seed_text])[0]
        if not tokens:
            print("None of the words are in the vocabulary. Try another start.")
            return seed_text
        tokens = pad_sequences([tokens], maxlen=max_len - 1, padding="pre")
        probs = model.predict(tokens, verbose=0)[0]
        if temperature > 0:
            p = np.exp(np.log(probs + 1e-9) / temperature)
            idx = np.random.choice(len(p), p=p / p.sum())
        else:
            idx = int(np.argmax(probs))
        word = tokenizer.index_word.get(idx, "")
        if not word:
            break
        seed_text += " " + word
    return seed_text


def main():
    ap = argparse.ArgumentParser(description="Next word prediction with RNN / LSTM")
    ap.add_argument("--data", default="data/pizza.txt", help="path to the training text file")
    ap.add_argument("--model", choices=["lstm", "rnn"], default="lstm")
    ap.add_argument("--epochs", type=int, default=200)
    ap.add_argument("--seed-text", default="pizza is")
    ap.add_argument("--words", type=int, default=10, help="how many words to generate")
    ap.add_argument("--temperature", type=float, default=0.0, help="0 = greedy, 0.5-1.0 = more varied")
    ap.add_argument("--model-dir", default="models")
    ap.add_argument("--retrain", action="store_true", help="ignore a saved model and train again")
    ap.add_argument("--interactive", action="store_true", help="ask for seed text and number of words")
    args = ap.parse_args()

    tf.random.set_seed(42)
    np.random.seed(42)

    os.makedirs(args.model_dir, exist_ok=True)
    mpath = os.path.join(args.model_dir, f"{args.model}_next_word.keras")
    tpath = os.path.join(args.model_dir, "tokenizer.json")
    cpath = os.path.join(args.model_dir, "config.json")

    if os.path.exists(mpath) and os.path.exists(tpath) and os.path.exists(cpath) and not args.retrain:
        print(f"Loading saved model: {mpath}")
        model = load_model(mpath)
        with open(tpath) as f:
            tokenizer = tokenizer_from_json(f.read())
        max_len = json.load(open(cpath))["max_sequence_len"]
    else:
        sentences = file_to_sentence_list(args.data)
        tokenizer, total_words, max_len, X, y = prepare_data(sentences)
        print(f"Sentences: {len(sentences)} | vocabulary: {total_words} | X: {X.shape}")
        model = build_model(args.model, total_words, max_len)
        model.fit(X, y, epochs=args.epochs, batch_size=32, verbose=0)
        loss, acc = model.evaluate(X, y, verbose=0)
        print(f"Trained {args.model.upper()} for {args.epochs} epochs | loss {loss:.4f} | accuracy {acc:.4f}")
        model.save(mpath)
        with open(tpath, "w") as f:
            f.write(tokenizer.to_json())
        json.dump({"max_sequence_len": int(max_len)}, open(cpath, "w"))

    if args.interactive:
        while True:
            seed = input("Enter starting text (or q to quit): ").strip()
            if seed.lower() == "q":
                break
            n = int(input("How many words to generate: "))
            print("\nGenerated:", generate_text(model, tokenizer, max_len, seed, n, args.temperature), "\n")
    else:
        print("\nGenerated:", generate_text(model, tokenizer, max_len, args.seed_text, args.words, args.temperature))


if __name__ == "__main__":
    main()
