# Code Walkthrough

Numbers below come from `data/pizza.txt` (79 sentences, about 1,700 words). Your numbers change with your own text.

## Step 1: Read sentences

```python
sentences = [s.strip() for s in re.split(r'(?<=[.!?])\s+', text) if s.strip()]
```

The regex splits after `.`, `?` or `!` when followed by whitespace. Result: **79 sentences**.

## Step 2: Tokenizer

```python
tokenizer = Tokenizer()
tokenizer.fit_on_texts(text_data)
total_words = len(tokenizer.word_index) + 1     # 687
```

- Words are lower-cased and punctuation is removed.
- Index 1 is the most frequent word (`the`; `and` is 2, `pizza` is 3). Index 0 is reserved for padding, hence `+ 1`.

## Step 3: N-gram sequences

```python
for line in text_data:
    token_list = tokenizer.texts_to_sequences([line])[0]
    for i in range(1, len(token_list)):
        input_sequences.append(token_list[:i+1])
```

For "Pizza, the delectable and iconic dish ..." -> `[3,1] [3,1,233] [3,1,233,2] [3,1,233,2,45] [3,1,233,2,45,35]`. One sentence with `n` words produces `n-1` examples. Total: **1,628 sequences**.

## Step 4: Padding and X / y

```python
max_sequence_len = max(len(seq) for seq in input_sequences)      # 40
input_sequences = pad_sequences(input_sequences, maxlen=max_sequence_len, padding='pre')
X, y = input_sequences[:, :-1], input_sequences[:, -1]
y = to_categorical(y, num_classes=total_words)
```

| Variable | Shape | Meaning |
|---|---|---|
| `X` | (1628, 39) | context words, left-padded with 0 |
| `y` | (1628, 687) | one-hot encoding of the next word |

Example row of `X`: `[0,0,0,...,0,3,1]` -> target `233` ("delectable").

## Step 5: Model

```python
model = Sequential([
    Input(shape=(max_sequence_len - 1,)),     # 39 words
    Embedding(total_words, 10),               # (39,) -> (39, 10)
    LSTM(128),                                # (39, 10) -> (128,)
    Dense(total_words, activation='softmax')  # (128,) -> (687,)
])
model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
```

| Layer | Output shape | Params |
|---|---|---|
| Embedding | (None, 39, 10) | 687 x 10 = 6,870 |
| LSTM | (None, 128) | 4 x 128 x (10+128+1) = 71,168 |
| Dense | (None, 687) | 128 x 687 + 687 = 88,623 |
| **Total** | | **166,661** |

For SimpleRNN replace `LSTM(128)` with `SimpleRNN(128)` (17,792 params, total 113,285).

## Step 6: Training

```python
model.fit(X, y, epochs=200, batch_size=32, verbose=0)
```

- 1,628 samples / batch 32 = 51 updates per epoch.
- `categorical_crossentropy` is used because `y` is one-hot (use `sparse_categorical_crossentropy` if `y` stays as integers).

## Step 7: Generate text

```python
def generate_text(seed_text, next_words, temperature=0.0):
    for _ in range(next_words):
        tokens = tokenizer.texts_to_sequences([seed_text])[0]
        tokens = pad_sequences([tokens], maxlen=max_sequence_len-1, padding='pre')
        probs  = model.predict(tokens, verbose=0)[0]
        idx    = np.argmax(probs)                  # or sample with temperature
        seed_text += " " + tokenizer.index_word[idx]
    return seed_text
```

| Part | Why |
|---|---|
| `texts_to_sequences` | convert the current text to integers |
| `pad_sequences(..., 'pre')` | same input length as in training |
| `argmax(probs)` | greedy: pick the most likely next word |
| temperature sampling | `p = exp(log(probs)/T)` then normalize; higher T = more random |
| loop `next_words` times | **this is the "how many words to generate" input** |

### Taking input from the user

```python
seed = input("Enter starting text (or q to quit): ")
n    = int(input("How many words to generate: "))
print(generate_text(seed, n))
```

or from the command line:

```bash
python src/next_word_lstm.py --seed-text "pizza is" --words 15
```

## Common errors

| Problem | Reason / fix |
|---|---|
| Output repeats the same word | greedy decoding on small data; use `--temperature 0.7` or more training text |
| `KeyError` / empty output | seed words are not in the vocabulary |
| Odd tokens like `dish—it` | a dash without spaces joins two words into one token; replace `—` with a space before tokenizing |
| `input_length` error | removed in newer Keras; use `Input(shape=...)` as in this repo |
| Very low accuracy | too few epochs or too little data |
| `FileNotFoundError` for `pizza.txt` | run from the repo root or change `DATA_PATH` |
