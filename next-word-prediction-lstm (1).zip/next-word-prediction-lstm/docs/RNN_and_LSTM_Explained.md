# RNN and LSTM Explained (for Next Word Prediction)

## 1. Why do we need RNNs?

A normal neural network (MLP/DNN) takes a fixed-size input and has **no memory**. Language is a **sequence**: the meaning of a word depends on the words before it.

> "The crust of the pizza is ____"  -> the next word depends on the whole sentence so far.

A **Recurrent Neural Network (RNN)** reads the sequence one word at a time and carries a **hidden state** (memory) from one step to the next.

## 2. Simple RNN

At every time step `t`:

```
h_t = tanh( W_x · x_t  +  W_h · h_(t-1)  +  b )
```

| Symbol | Meaning |
|---|---|
| `x_t` | input at step t (word embedding) |
| `h_(t-1)` | previous hidden state (memory) |
| `h_t` | new hidden state |
| `W_x, W_h, b` | learned weights (same at every step) |

```mermaid
flowchart LR
    x1["x1: the"] --> A1[RNN] --> h1((h1))
    h1 --> A2[RNN]
    x2["x2: crust"] --> A2 --> h2((h2))
    h2 --> A3[RNN]
    x3["x3: of"] --> A3 --> h3((h3)) --> y["softmax: next word"]
```

**Parameters:** `units x (input_dim + units + 1)`. With 128 units and 10-dim embeddings: `128 x (10 + 128 + 1) = 17,792`.

### The problem: vanishing gradient

Training uses **Backpropagation Through Time (BPTT)**. The gradient is multiplied by `W_h` and the `tanh` derivative at every step back in time. If these factors are below 1, the gradient shrinks exponentially, so the network **cannot learn long-range dependencies** (it forgets early words). (If they are above 1, gradients explode.)

## 3. LSTM (Long Short-Term Memory)

LSTM fixes this with a separate **cell state** `c_t` (a "conveyor belt" of memory) and **three gates** that decide what to forget, write and output. Gates are sigmoid layers (values between 0 and 1).

| Gate | Equation | Job |
|---|---|---|
| Forget gate | `f_t = σ(W_f·[h_(t-1), x_t] + b_f)` | what to **erase** from the cell state |
| Input gate | `i_t = σ(W_i·[h_(t-1), x_t] + b_i)` | what new information to **write** |
| Candidate | `c~_t = tanh(W_c·[h_(t-1), x_t] + b_c)` | the new information itself |
| Cell update | `c_t = f_t ⊙ c_(t-1) + i_t ⊙ c~_t` | forget old + add new |
| Output gate | `o_t = σ(W_o·[h_(t-1), x_t] + b_o)` | what part of memory to **expose** |
| Hidden state | `h_t = o_t ⊙ tanh(c_t)` | output of this step |

(`⊙` = element-wise multiplication.)

```mermaid
flowchart LR
    subgraph cell [LSTM cell]
    F["Forget gate"] --> C(("Cell state c_t"))
    I["Input gate + candidate"] --> C
    C --> O["Output gate"] --> H(("h_t"))
    end
    X["x_t"] --> F & I & O
    Hprev["h_(t-1)"] --> F & I & O
    Cprev["c_(t-1)"] --> C
```

Because the cell state is updated mostly by **addition** (not repeated multiplication), gradients flow back through many steps much more easily.

**Parameters:** 4 sets of weights (forget, input, candidate, output):

```
4 x units x (input_dim + units + 1)  =  4 x 128 x (10 + 128 + 1)  =  71,168
```

## 4. RNN vs LSTM vs GRU

| | SimpleRNN | LSTM | GRU |
|---|---|---|---|
| Memory | hidden state only | hidden + cell state | hidden state |
| Gates | none | 3 (forget, input, output) | 2 (update, reset) |
| Params (units=128, input=10) | 17,792 | 71,168 | 53,760 |
| Long dependencies | poor | good | good |
| Speed | fastest | slowest | in between |

## 5. How next word prediction works

1. **Tokenize** words to integers and build n-gram sequences (`[3,1]`, `[3,1,233]`, ...).
2. **Embedding** turns each integer into a dense vector.
3. The **RNN/LSTM reads the words in order** and its last hidden state summarizes the context.
4. A **Dense + softmax** layer outputs a probability for every word in the vocabulary.
5. Training uses **categorical cross-entropy** and the **Adam** optimizer.
6. **Generation:** pick the next word (argmax or sample), append it to the text, repeat for N words.

## 6. Results from this project

Same data (79 sentences, vocabulary 687, 1,628 training sequences), 128 units, 200 epochs:

| Model | Params | Final loss | Train accuracy | Time |
|---|---|---|---|---|
| SimpleRNN | 113,285 | ~0.08 | ~96.5% | ~108 s |
| LSTM | 166,661 | ~0.12 | ~96.3% | ~237 s |

Both memorize this small corpus (SimpleRNN even reaches a lower loss and trains about 2x faster). The LSTM's advantage appears on longer sequences and larger, real-world text. Times are from a CPU run and numbers vary a little between runs.

## 7. Interview questions

1. Why can't a normal DNN handle sequences well?
2. Write the SimpleRNN update equation. What does `h_t` represent?
3. What is BPTT and why does the gradient vanish?
4. Name the LSTM gates and what each one does.
5. Why does the LSTM cell state help with long-term memory?
6. How many parameters does an LSTM layer have? (`4 x units x (input + units + 1)`)
7. Why `padding='pre'` for an RNN/LSTM?
8. What is the effect of `temperature` when generating text?
9. Why is accuracy of 95% on training data not a good sign here?
10. How would you improve this model? (more data, stacked/bidirectional LSTM, dropout, pretrained embeddings or a Transformer)
